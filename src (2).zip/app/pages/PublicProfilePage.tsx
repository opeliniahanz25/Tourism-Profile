import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Lock } from 'lucide-react';
import panglaoCrest from 'figma:asset/49ddcf43fbedf9b16ada70b003cf04ef33725af2.png';
import boholLogo from 'figma:asset/65e6c85fd1eb9a1d4c6cf01f0f2e8b18e12a088e.png';
import { initialProfileData } from '../data/profileData';
import { useState, useEffect } from 'react';
import type { ProfileData } from '../data/profileData';
import { TourismResourcesSection, InstitutionalElementsSection } from '../components/PublicProfileSections';

export default function PublicProfilePage() {
  const navigate = useNavigate();
  const [profileData, setProfileData] = useState<ProfileData>(initialProfileData);
  const [diagrams, setDiagrams] = useState<Array<{ id: string; url: string; title: string }>>([]);

  useEffect(() => {
    // Load saved data from localStorage
    const savedData = localStorage.getItem('profileData');
    if (savedData) {
      setProfileData(JSON.parse(savedData));
    }
    const savedDiagrams = localStorage.getItem('diagrams');
    if (savedDiagrams) {
      setDiagrams(JSON.parse(savedDiagrams));
    }
  }, []);

  const handleAdminAccess = () => {
    navigate('/admin');
  };

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-md border-b-4 border-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img src={panglaoCrest} alt="Panglao Crest" className="h-20 w-20 object-contain" />
              <div>
                <p className="text-xl font-bold text-blue-700">MUNICIPALITY OF PANGLAO</p>
                <p className="text-sm text-gray-600">Office of the Municipal Tourism Officer</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleAdminAccess} className="bg-blue-600 hover:bg-blue-700">
                <Lock className="h-4 w-4 mr-2" />
                Admin Panel
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Title Section with Logos */}
        <div className="bg-white p-6 rounded-lg shadow-lg mb-8 border-2 border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <img src={panglaoCrest} alt="Panglao Seal" className="h-24 w-24 object-contain" />
            <div className="flex-1 text-center px-4">
              <p className="text-sm text-gray-600">Republic of the Philippines</p>
              <p className="text-sm text-gray-600">Province of Bohol</p>
              <p className="text-lg font-bold text-gray-800">MUNICIPALITY OF PANGLAO</p>
            </div>
            <img src={boholLogo} alt="Behold Bohol" className="h-24 w-auto object-contain" />
          </div>
          <h2 className="text-center text-xl font-semibold text-cyan-500 mb-3">
            OFFICE OF THE MUNICIPAL TOURISM OFFICER
          </h2>
          <div className="bg-gray-200 py-4 px-6 text-center">
            <h3 className="text-3xl font-bold text-gray-900">
              PANGLAO LOCAL TOURISM INDUSTRY PROFILE
            </h3>
          </div>
        </div>

        {/* Basic LGU Information */}
        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl">I. Basic LGU Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-300">
                <tbody>
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3 font-semibold bg-gray-50" colSpan={2}>
                      Name of LGU: <span className="font-bold">{profileData.basicInfo.name}</span>
                    </td>
                  </tr>
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3 font-semibold bg-gray-50">
                      Province: <span className="font-bold">{profileData.basicInfo.province}</span>
                    </td>
                    <td className="border border-gray-300 p-3 font-semibold bg-gray-50">
                      Region: <span className="font-bold">{profileData.basicInfo.region}</span>
                    </td>
                  </tr>
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3">
                      Population: {profileData.basicInfo.population}
                    </td>
                    <td className="border border-gray-300 p-3">
                      Land Area: <span className="font-bold">{profileData.basicInfo.landArea}</span>
                    </td>
                  </tr>
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3">
                      Number of Barangays: <span className="font-bold">{profileData.basicInfo.numberOfBarangays}</span>
                    </td>
                    <td className="border border-gray-300 p-3">
                      Ethnic Groups: <span className="font-bold">{profileData.basicInfo.ethnicGroups}</span>
                    </td>
                  </tr>
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3" colSpan={2}>
                      <div className="font-semibold mb-2">Religions:</div>
                      <div className="flex gap-4">
                        {profileData.religions.map((religion, idx) => (
                          <span key={idx} className="font-bold">{religion}</span>
                        ))}
                      </div>
                    </td>
                  </tr>
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3" colSpan={2}>
                      <div className="font-semibold mb-2">Language/s Spoken:</div>
                      <div className="flex gap-4">
                        {profileData.languages.map((lang, idx) => (
                          <span key={idx} className="font-bold">{lang}</span>
                        ))}
                      </div>
                    </td>
                  </tr>
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3" colSpan={2}>
                      <div className="font-semibold mb-2">Major Economic Activities:</div>
                      <div className="flex gap-4">
                        {profileData.economicActivities.map((activity, idx) => (
                          <span key={idx} className="font-bold">{activity}</span>
                        ))}
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Local Government Officials */}
        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl">Local Government Officials</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full border-collapse border border-gray-300">
                <tbody>
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3 font-semibold bg-blue-50" colSpan={2}>
                      Mayor: <span className="font-bold">{profileData.officials.mayor}</span>
                    </td>
                  </tr>
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3 font-semibold bg-blue-50" colSpan={2}>
                      Vice Mayor: <span className="font-bold">{profileData.officials.viceMayor}</span>
                    </td>
                  </tr>
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3 font-semibold bg-gray-50" colSpan={2}>
                      Sangguniang Bayan Members:
                    </td>
                  </tr>
                  {profileData.officials.sangguniang.map((member, idx) => {
                    if (idx % 2 === 0) {
                      return (
                        <tr key={idx} className="border border-gray-300">
                          <td className="border border-gray-300 p-3 font-bold">
                            {member}
                          </td>
                          <td className="border border-gray-300 p-3 font-bold">
                            {profileData.officials.sangguniang[idx + 1] || ''}
                          </td>
                        </tr>
                      );
                    }
                    return null;
                  })}
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3" colSpan={2}>
                      Tourism Officer: <span className="font-bold">{profileData.officials.tourismOfficer}</span>
                    </td>
                  </tr>
                  <tr className="border border-gray-300">
                    <td className="border border-gray-300 p-3" colSpan={2}>
                      Planning and Development Coordinator: <span className="font-bold">{profileData.officials.planningCoordinator}</span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Section II - Tourism Resources */}
        <TourismResourcesSection profileData={profileData} />

        {/* Section III - Institutional Elements */}
        <InstitutionalElementsSection profileData={profileData} />

        {/* Diagrams Section */}
        {diagrams.length > 0 && (
          <Card className="mb-8 shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl">Additional Diagrams & Charts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {diagrams.map((diagram) => (
                  <div key={diagram.id} className="border rounded-lg p-4 bg-white shadow">
                    <h4 className="font-semibold mb-3 text-center">{diagram.title}</h4>
                    <img src={diagram.url} alt={diagram.title} className="w-full h-auto rounded" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sm">© 2026 Municipality of Panglao - Office of the Municipal Tourism Officer</p>
          <p className="text-xs mt-2 text-gray-400">Republic of the Philippines | Province of Bohol</p>
        </div>
      </footer>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { ScrollArea } from '../components/ui/scroll-area';
import { ArrowLeft, Save, Upload, X } from 'lucide-react';
import panglaoCrest from 'figma:asset/49ddcf43fbedf9b16ada70b003cf04ef33725af2.png';
import { initialProfileData, type ProfileData } from '../data/profileData';
import { toast } from 'sonner';
import { Toaster } from '../components/ui/sonner';
import { TourismAttractionsTab, AccommodationTab, TransportationTab } from '../components/AdminTabs';
import { InstitutionalTab, EmergencyContactsTab, TourismEducationTab, TourismProjectsTab, SafetySecurityTab } from '../components/AdminTabsContinued';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const [profileData, setProfileData] = useState<ProfileData>(initialProfileData);
  const [diagrams, setDiagrams] = useState<Array<{ id: string; url: string; title: string }>>([]);
  const [newDiagramTitle, setNewDiagramTitle] = useState('');
  const [tourismMapFile, setTourismMapFile] = useState<string>('');
  const [hazardMapFiles, setHazardMapFiles] = useState<string[]>([]);

  useEffect(() => {
    // Load saved data
    const savedData = localStorage.getItem('profileData');
    if (savedData) {
      setProfileData(JSON.parse(savedData));
    }
    const savedDiagrams = localStorage.getItem('diagrams');
    if (savedDiagrams) {
      setDiagrams(JSON.parse(savedDiagrams));
    }
  }, [navigate]);

  const handleSave = () => {
    localStorage.setItem('profileData', JSON.stringify(profileData));
    localStorage.setItem('diagrams', JSON.stringify(diagrams));
    toast.success('Changes saved successfully!');
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const newDiagram = {
          id: Date.now().toString(),
          url: event.target?.result as string,
          title: newDiagramTitle || file.name,
        };
        setDiagrams([...diagrams, newDiagram]);
        setNewDiagramTitle('');
        toast.success('Diagram uploaded successfully!');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTourismMapUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const mapUrl = event.target?.result as string;
        setProfileData({ ...profileData, tourismMapUrl: mapUrl });
        toast.success('Tourism map uploaded!');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleHazardMapUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const fileReaders: Promise<string>[] = [];
      
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const promise = new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = (event) => {
            resolve(event.target?.result as string);
          };
          reader.readAsDataURL(file);
        });
        fileReaders.push(promise);
      }

      Promise.all(fileReaders).then((urls) => {
        setProfileData({
          ...profileData,
          hazardMapsUrls: [...profileData.hazardMapsUrls, ...urls],
        });
        toast.success(`${urls.length} hazard map(s) uploaded!`);
      });
    }
  };

  const removeHazardMap = (index: number) => {
    const newMaps = profileData.hazardMapsUrls.filter((_, idx) => idx !== index);
    setProfileData({ ...profileData, hazardMapsUrls: newMaps });
    toast.success('Hazard map removed!');
  };

  const removeDiagram = (id: string) => {
    setDiagrams(diagrams.filter((d) => d.id !== id));
    toast.success('Diagram removed!');
  };

  const updateBasicInfo = (field: keyof ProfileData['basicInfo'], value: string) => {
    setProfileData({
      ...profileData,
      basicInfo: {
        ...profileData.basicInfo,
        [field]: value,
      },
    });
  };

  const updateOfficials = (field: keyof ProfileData['officials'], value: string) => {
    setProfileData({
      ...profileData,
      officials: {
        ...profileData.officials,
        [field]: value,
      },
    });
  };

  const updateSangguniang = (index: number, value: string) => {
    const newSangguniang = [...profileData.officials.sangguniang];
    newSangguniang[index] = value;
    setProfileData({
      ...profileData,
      officials: {
        ...profileData.officials,
        sangguniang: newSangguniang,
      },
    });
  };

  const updateLanguages = (index: number, value: string) => {
    const newLanguages = [...profileData.languages];
    newLanguages[index] = value;
    setProfileData({
      ...profileData,
      languages: newLanguages,
    });
  };

  const updateReligions = (index: number, value: string) => {
    const newReligions = [...profileData.religions];
    newReligions[index] = value;
    setProfileData({
      ...profileData,
      religions: newReligions,
    });
  };

  const updateEconomicActivities = (index: number, value: string) => {
    const newActivities = [...profileData.economicActivities];
    newActivities[index] = value;
    setProfileData({
      ...profileData,
      economicActivities: newActivities,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Toaster />
      
      {/* Header */}
      <header className="bg-white shadow-md border-b-4 border-blue-600 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img src={panglaoCrest} alt="Panglao Crest" className="h-16 w-16 object-contain" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Admin Dashboard</h1>
                <p className="text-sm text-gray-600">Edit Tourism Industry Profile</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => navigate('/')} variant="outline">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Profile
              </Button>
              <Button onClick={handleSave} className="bg-green-600 hover:bg-green-700">
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 mb-6">
            <TabsTrigger value="basic">Basic Info</TabsTrigger>
            <TabsTrigger value="officials">Officials</TabsTrigger>
            <TabsTrigger value="attractions">Attractions</TabsTrigger>
            <TabsTrigger value="accommodation">Accommodation</TabsTrigger>
            <TabsTrigger value="transportation">Transport</TabsTrigger>
            <TabsTrigger value="institutional">Institutional</TabsTrigger>
            <TabsTrigger value="education">Education</TabsTrigger>
            <TabsTrigger value="safety">Safety</TabsTrigger>
          </TabsList>

          {/* Basic Information Tab */}
          <TabsContent value="basic">
            <Card>
              <CardHeader>
                <CardTitle>Edit Basic LGU Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name of LGU</Label>
                    <Input
                      id="name"
                      value={profileData.basicInfo.name}
                      onChange={(e) => updateBasicInfo('name', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="province">Province</Label>
                    <Input
                      id="province"
                      value={profileData.basicInfo.province}
                      onChange={(e) => updateBasicInfo('province', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="region">Region</Label>
                    <Input
                      id="region"
                      value={profileData.basicInfo.region}
                      onChange={(e) => updateBasicInfo('region', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="population">Population</Label>
                    <Input
                      id="population"
                      value={profileData.basicInfo.population}
                      onChange={(e) => updateBasicInfo('population', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="landArea">Land Area</Label>
                    <Input
                      id="landArea"
                      value={profileData.basicInfo.landArea}
                      onChange={(e) => updateBasicInfo('landArea', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="barangays">Number of Barangays</Label>
                    <Input
                      id="barangays"
                      value={profileData.basicInfo.numberOfBarangays}
                      onChange={(e) => updateBasicInfo('numberOfBarangays', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ethnicGroups">Ethnic Groups</Label>
                    <Input
                      id="ethnicGroups"
                      value={profileData.basicInfo.ethnicGroups}
                      onChange={(e) => updateBasicInfo('ethnicGroups', e.target.value)}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <Label className="mb-2 block">Religions</Label>
                    <div className="space-y-2">
                      {profileData.religions.map((religion, idx) => (
                        <Input
                          key={idx}
                          value={religion}
                          onChange={(e) => updateReligions(idx, e.target.value)}
                          placeholder={`Religion ${idx + 1}`}
                        />
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="mb-2 block">Languages Spoken</Label>
                    <div className="space-y-2">
                      {profileData.languages.map((lang, idx) => (
                        <Input
                          key={idx}
                          value={lang}
                          onChange={(e) => updateLanguages(idx, e.target.value)}
                          placeholder={`Language ${idx + 1}`}
                        />
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label className="mb-2 block">Major Economic Activities</Label>
                    <div className="space-y-2">
                      {profileData.economicActivities.map((activity, idx) => (
                        <Input
                          key={idx}
                          value={activity}
                          onChange={(e) => updateEconomicActivities(idx, e.target.value)}
                          placeholder={`Activity ${idx + 1}`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Officials Tab */}
          <TabsContent value="officials">
            <Card>
              <CardHeader>
                <CardTitle>Edit Local Government Officials</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="mayor">Mayor</Label>
                    <Input
                      id="mayor"
                      value={profileData.officials.mayor}
                      onChange={(e) => updateOfficials('mayor', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="viceMayor">Vice Mayor</Label>
                    <Input
                      id="viceMayor"
                      value={profileData.officials.viceMayor}
                      onChange={(e) => updateOfficials('viceMayor', e.target.value)}
                    />
                  </div>
                </div>

                <div>
                  <Label className="mb-2 block">Sangguniang Bayan Members</Label>
                  <div className="space-y-2">
                    {profileData.officials.sangguniang.map((member, idx) => (
                      <Input
                        key={idx}
                        value={member}
                        onChange={(e) => updateSangguniang(idx, e.target.value)}
                        placeholder={`Member ${idx + 1}`}
                      />
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="tourismOfficer">Tourism Officer</Label>
                    <Input
                      id="tourismOfficer"
                      value={profileData.officials.tourismOfficer}
                      onChange={(e) => updateOfficials('tourismOfficer', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="planningCoordinator">Planning and Development Coordinator</Label>
                    <Input
                      id="planningCoordinator"
                      value={profileData.officials.planningCoordinator}
                      onChange={(e) => updateOfficials('planningCoordinator', e.target.value)}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tourism Attractions Tab */}
          <TabsContent value="attractions">
            <div className="space-y-6">
              <TourismAttractionsTab profileData={profileData} setProfileData={setProfileData} />
              
              {/* Tourism Map Upload */}
              <Card>
                <CardHeader>
                  <CardTitle>Local Tourism Map</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="tourismMap">Upload Tourism Map</Label>
                      <Input
                        id="tourismMap"
                        type="file"
                        accept="image/*"
                        onChange={handleTourismMapUpload}
                        className="mt-2"
                      />
                    </div>
                    {profileData.tourismMapUrl && (
                      <div className="border rounded-lg p-4">
                        <p className="text-sm font-semibold mb-2">Current Map:</p>
                        <img src={profileData.tourismMapUrl} alt="Tourism Map" className="w-full h-auto max-h-96 object-contain rounded" />
                        <Button
                          variant="destructive"
                          size="sm"
                          className="mt-2"
                          onClick={() => setProfileData({ ...profileData, tourismMapUrl: '' })}
                        >
                          Remove Map
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Accommodation Tab */}
          <TabsContent value="accommodation">
            <AccommodationTab profileData={profileData} setProfileData={setProfileData} />
          </TabsContent>

          {/* Transportation Tab */}
          <TabsContent value="transportation">
            <TransportationTab profileData={profileData} setProfileData={setProfileData} />
          </TabsContent>

          {/* Institutional Tab */}
          <TabsContent value="institutional">
            <div className="space-y-6">
              <InstitutionalTab profileData={profileData} setProfileData={setProfileData} />
              <EmergencyContactsTab profileData={profileData} setProfileData={setProfileData} />
            </div>
          </TabsContent>

          {/* Education & Projects Tab */}
          <TabsContent value="education">
            <div className="space-y-6">
              <TourismEducationTab profileData={profileData} setProfileData={setProfileData} />
              <TourismProjectsTab profileData={profileData} setProfileData={setProfileData} />
            </div>
          </TabsContent>

          {/* Safety & Security Tab */}
          <TabsContent value="safety">
            <div className="space-y-6">
              <SafetySecurityTab profileData={profileData} setProfileData={setProfileData} />
              
              {/* Hazard Maps */}
              <Card>
                <CardHeader>
                  <CardTitle>Multiple-hazard Maps</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="hazardMaps">Upload Hazard Maps (can select multiple)</Label>
                      <Input
                        id="hazardMaps"
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleHazardMapUpload}
                        className="mt-2"
                      />
                    </div>
                    {profileData.hazardMapsUrls.length > 0 && (
                      <div className="space-y-4">
                        <p className="text-sm font-semibold">Uploaded Hazard Maps ({profileData.hazardMapsUrls.length}):</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {profileData.hazardMapsUrls.map((mapUrl, idx) => (
                            <div key={idx} className="border rounded-lg p-4 relative">
                              <Button
                                variant="destructive"
                                size="sm"
                                className="absolute top-2 right-2"
                                onClick={() => removeHazardMap(idx)}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                              <img src={mapUrl} alt={`Hazard Map ${idx + 1}`} className="w-full h-auto rounded" />
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Additional Diagrams */}
              <Card>
                <CardHeader>
                  <CardTitle>Additional Diagrams & Charts</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Upload Section */}
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 bg-gray-50">
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="diagramTitle">Diagram Title</Label>
                        <Input
                          id="diagramTitle"
                          placeholder="Enter diagram title"
                          value={newDiagramTitle}
                          onChange={(e) => setNewDiagramTitle(e.target.value)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="diagramUpload">Upload Diagram/Chart</Label>
                        <div className="flex items-center gap-2">
                          <Input
                            id="diagramUpload"
                            type="file"
                            accept="image/*"
                            onChange={handleImageUpload}
                            className="flex-1"
                          />
                          <Button type="button" className="bg-blue-600 hover:bg-blue-700">
                            <Upload className="h-4 w-4 mr-2" />
                            Upload
                          </Button>
                        </div>
                        <p className="text-xs text-gray-500">Accepts: PNG, JPG, GIF, SVG</p>
                      </div>
                    </div>
                  </div>

                  {/* Existing Diagrams */}
                  <div>
                    <h3 className="font-semibold mb-4">Uploaded Diagrams ({diagrams.length})</h3>
                    {diagrams.length === 0 ? (
                      <div className="text-center py-12 text-gray-500">
                        <p>No diagrams uploaded yet.</p>
                        <p className="text-sm">Upload your first diagram above.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {diagrams.map((diagram) => (
                          <div key={diagram.id} className="border rounded-lg p-4 bg-white relative">
                            <Button
                              variant="destructive"
                              size="sm"
                              className="absolute top-2 right-2"
                              onClick={() => removeDiagram(diagram.id)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                            <h4 className="font-semibold mb-3">{diagram.title}</h4>
                            <img
                              src={diagram.url}
                              alt={diagram.title}
                              className="w-full h-48 object-contain border rounded"
                            />
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
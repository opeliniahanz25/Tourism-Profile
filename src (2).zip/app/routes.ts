import { createBrowserRouter } from "react-router";
import PublicProfilePage from "./pages/PublicProfilePage";
import AdminDashboard from "./pages/AdminDashboard";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: PublicProfilePage,
  },
  {
    path: "/admin",
    Component: AdminDashboard,
  },
]);
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import type { ProfileData } from '../data/profileData';

interface ProfileSectionsProps {
  profileData: ProfileData;
}

export function TourismResourcesSection({ profileData }: ProfileSectionsProps) {
  return (
    <>
      {/* Tourism Attractions */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl">II. Profile of Tourism Resources and Assets</CardTitle>
          <p className="text-sm text-gray-600 mt-2">A. Tourism Attractions and Activities</p>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">CATEGORY</th>
                  <th className="border border-gray-300 p-3 font-semibold">ATTRACTION</th>
                  <th className="border border-gray-300 p-3 font-semibold">LOCATION</th>
                  <th className="border border-gray-300 p-3 font-semibold">ACTIVITIES</th>
                </tr>
              </thead>
              <tbody>
                {profileData.tourismAttractions.length > 0 ? (
                  profileData.tourismAttractions.map((attraction) => (
                    <tr key={attraction.id} className="border border-gray-300">
                      <td className="border border-gray-300 p-3">{attraction.category}</td>
                      <td className="border border-gray-300 p-3">{attraction.attraction}</td>
                      <td className="border border-gray-300 p-3">{attraction.location}</td>
                      <td className="border border-gray-300 p-3">{attraction.activities}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="border border-gray-300 p-8 text-center text-gray-500">
                      No tourism attractions added yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Local Tourism Map */}
      {profileData.tourismMapUrl && (
        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl">B. Local Tourism Map</CardTitle>
          </CardHeader>
          <CardContent>
            <img src={profileData.tourismMapUrl} alt="Local Tourism Map" className="w-full h-auto rounded-lg" />
          </CardContent>
        </Card>
      )}

      {/* Accommodation and Facilities */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">C. Accommodation and other Facilities</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">NATURE</th>
                  <th className="border border-gray-300 p-3 font-semibold">ESTABLISHMENT/FACILITY</th>
                  <th className="border border-gray-300 p-3 font-semibold">LOCATION</th>
                  <th className="border border-gray-300 p-3 font-semibold">CONTACT DETAILS</th>
                </tr>
              </thead>
              <tbody>
                {profileData.accommodationFacilities.length > 0 ? (
                  profileData.accommodationFacilities.map((facility) => (
                    <tr key={facility.id} className="border border-gray-300">
                      <td className="border border-gray-300 p-3">{facility.nature}</td>
                      <td className="border border-gray-300 p-3">{facility.establishment}</td>
                      <td className="border border-gray-300 p-3">{facility.location}</td>
                      <td className="border border-gray-300 p-3">{facility.contactDetails}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="border border-gray-300 p-8 text-center text-gray-500">
                      No accommodation facilities added yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Accommodation Profile */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">D. Accommodation Profile</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">NAME OF ESTABLISHMENT</th>
                  <th className="border border-gray-300 p-3 font-semibold">TYPE</th>
                  <th className="border border-gray-300 p-3 font-semibold"># OF ROOMS</th>
                  <th className="border border-gray-300 p-3 font-semibold">AVERAGE RATE</th>
                  <th className="border border-gray-300 p-3 font-semibold">OCCUPANCY RATE</th>
                </tr>
              </thead>
              <tbody>
                {profileData.accommodationProfiles.length > 0 ? (
                  profileData.accommodationProfiles.map((profile) => (
                    <tr key={profile.id} className="border border-gray-300">
                      <td className="border border-gray-300 p-3">{profile.name}</td>
                      <td className="border border-gray-300 p-3">{profile.type}</td>
                      <td className="border border-gray-300 p-3">{profile.numberOfRooms}</td>
                      <td className="border border-gray-300 p-3">{profile.averageRate}</td>
                      <td className="border border-gray-300 p-3">{profile.occupancyRate}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="border border-gray-300 p-8 text-center text-gray-500">
                      No accommodation profiles added yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Transportation */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">E. Transportation</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">TYPE</th>
                  <th className="border border-gray-300 p-3 font-semibold">SCHEDULES</th>
                  <th className="border border-gray-300 p-3 font-semibold">ROUTE</th>
                  <th className="border border-gray-300 p-3 font-semibold">AVERAGE FARE</th>
                </tr>
              </thead>
              <tbody>
                {profileData.transportation.map((trans) => (
                  <tr key={trans.id} className="border border-gray-300">
                    <td className="border border-gray-300 p-3 font-semibold">{trans.type}</td>
                    <td className="border border-gray-300 p-3">{trans.schedules}</td>
                    <td className="border border-gray-300 p-3">{trans.route}</td>
                    <td className="border border-gray-300 p-3">{trans.averageFare}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </>
  );
}

export function InstitutionalElementsSection({ profileData }: ProfileSectionsProps) {
  return (
    <>
      {/* Institutional Elements Header */}
      <div className="bg-gradient-to-r from-blue-500 to-cyan-400 text-white p-4 rounded-lg shadow-lg mb-6 mt-8">
        <h2 className="text-center text-2xl font-bold">III. INSTITUTIONAL ELEMENTS</h2>
      </div>

      {/* Accommodation and Other Facilities Groups */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">A. Accommodation and Other Facilities</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">GROUPS</th>
                  <th className="border border-gray-300 p-3 font-semibold">ROLE IN TOURISM</th>
                  <th className="border border-gray-300 p-3 font-semibold">NAME OF ORGANIZATION AND HEAD</th>
                  <th className="border border-gray-300 p-3 font-semibold">ADDRESS AND CONTACT DETAILS</th>
                </tr>
              </thead>
              <tbody>
                {profileData.institutionalElements.length > 0 ? (
                  profileData.institutionalElements.map((element) => (
                    <tr key={element.id} className="border border-gray-300">
                      <td className="border border-gray-300 p-3">{element.groups}</td>
                      <td className="border border-gray-300 p-3">{element.roleInTourism}</td>
                      <td className="border border-gray-300 p-3">{element.organizationName}</td>
                      <td className="border border-gray-300 p-3">{element.addressContact}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="border border-gray-300 p-8 text-center text-gray-500">
                      No institutional elements added yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Labor Force */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">F. Labor Force</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">CATEGORY</th>
                  <th colSpan={2} className="border border-gray-300 p-3 font-semibold">NUMBER OF EMPLOYEES</th>
                </tr>
                <tr className="bg-gray-50">
                  <th className="border border-gray-300 p-3"></th>
                  <th className="border border-gray-300 p-3 font-semibold">MALE</th>
                  <th className="border border-gray-300 p-3 font-semibold">FEMALE</th>
                </tr>
              </thead>
              <tbody>
                {profileData.laborForce.map((labor, idx) => (
                  <tr key={idx} className="border border-gray-300">
                    <td className="border border-gray-300 p-3 font-semibold">{labor.category}</td>
                    <td className="border border-gray-300 p-3">{labor.male}</td>
                    <td className="border border-gray-300 p-3">{labor.female}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Revenue Contributions */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">B. Total Revenue Contributions to LGU for the Past 3 Years</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">CATEGORY</th>
                  <th colSpan={3} className="border border-gray-300 p-3 font-semibold">TOTAL REVENUE CONTRIBUTIONS (PhP)</th>
                </tr>
                <tr className="bg-gray-50">
                  <th className="border border-gray-300 p-3"></th>
                  <th className="border border-gray-300 p-3 font-semibold">Year 1</th>
                  <th className="border border-gray-300 p-3 font-semibold">Year 2</th>
                  <th className="border border-gray-300 p-3 font-semibold">Year 3</th>
                </tr>
              </thead>
              <tbody>
                {profileData.revenueContributions.map((revenue, idx) => (
                  <tr key={idx} className="border border-gray-300">
                    <td className="border border-gray-300 p-3 font-semibold">{revenue.category}</td>
                    <td className="border border-gray-300 p-3">{revenue.year1}</td>
                    <td className="border border-gray-300 p-3">{revenue.year2}</td>
                    <td className="border border-gray-300 p-3">{revenue.year3}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Emergency Contacts */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">C. Emergency Contacts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">OFFICE/AGENCY</th>
                  <th className="border border-gray-300 p-3 font-semibold">CONTACT PERSON</th>
                  <th className="border border-gray-300 p-3 font-semibold">ADDRESS</th>
                  <th className="border border-gray-300 p-3 font-semibold">PHONE NUMBER</th>
                </tr>
              </thead>
              <tbody>
                {profileData.emergencyContacts.length > 0 ? (
                  profileData.emergencyContacts.map((contact) => (
                    <tr key={contact.id} className="border border-gray-300">
                      <td className="border border-gray-300 p-3">{contact.office}</td>
                      <td className="border border-gray-300 p-3">{contact.contactPerson}</td>
                      <td className="border border-gray-300 p-3">{contact.address}</td>
                      <td className="border border-gray-300 p-3">{contact.phoneNumber}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="border border-gray-300 p-8 text-center text-gray-500">
                      No emergency contacts added yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Tourism Education */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">D. Tourism Education</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">Title of Training/Study Tours</th>
                  <th className="border border-gray-300 p-3 font-semibold">Date, Venue</th>
                  <th colSpan={2} className="border border-gray-300 p-3 font-semibold">Number of Participants</th>
                  <th className="border border-gray-300 p-3 font-semibold">Participant Groups</th>
                  <th className="border border-gray-300 p-3 font-semibold">Organized/Conducted by</th>
                </tr>
                <tr className="bg-gray-50">
                  <th className="border border-gray-300 p-2"></th>
                  <th className="border border-gray-300 p-2"></th>
                  <th className="border border-gray-300 p-2 font-semibold">Male</th>
                  <th className="border border-gray-300 p-2 font-semibold">Female</th>
                  <th className="border border-gray-300 p-2"></th>
                  <th className="border border-gray-300 p-2"></th>
                </tr>
              </thead>
              <tbody>
                {profileData.tourismEducation.length > 0 ? (
                  profileData.tourismEducation.map((edu) => (
                    <tr key={edu.id} className="border border-gray-300">
                      <td className="border border-gray-300 p-3">{edu.title}</td>
                      <td className="border border-gray-300 p-3">{edu.dateVenue}</td>
                      <td className="border border-gray-300 p-3">{edu.participantsMale}</td>
                      <td className="border border-gray-300 p-3">{edu.participantsFemale}</td>
                      <td className="border border-gray-300 p-3">{edu.participantGroups}</td>
                      <td className="border border-gray-300 p-3">{edu.organizedBy}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="border border-gray-300 p-8 text-center text-gray-500">
                      No tourism education records added yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Tourism Projects */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">E. Tourism Projects in the Past 5 Years</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">Name of Project</th>
                  <th className="border border-gray-300 p-3 font-semibold">Duration</th>
                  <th className="border border-gray-300 p-3 font-semibold">Implementing Agency</th>
                  <th className="border border-gray-300 p-3 font-semibold">Partners</th>
                  <th className="border border-gray-300 p-3 font-semibold">Amount</th>
                  <th className="border border-gray-300 p-3 font-semibold">Sources of Funds</th>
                </tr>
              </thead>
              <tbody>
                {profileData.tourismProjects.length > 0 ? (
                  profileData.tourismProjects.map((project) => (
                    <tr key={project.id} className="border border-gray-300">
                      <td className="border border-gray-300 p-3">{project.name}</td>
                      <td className="border border-gray-300 p-3">{project.duration}</td>
                      <td className="border border-gray-300 p-3">{project.implementingAgency}</td>
                      <td className="border border-gray-300 p-3">{project.partners}</td>
                      <td className="border border-gray-300 p-3">{project.amount}</td>
                      <td className="border border-gray-300 p-3">{project.sourcesOfFunds}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="border border-gray-300 p-8 text-center text-gray-500">
                      No tourism projects added yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Peace and Order */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">F. Peace and Order and Incidence of Crime</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">Nature of Incident</th>
                  <th className="border border-gray-300 p-3 font-semibold">Description</th>
                </tr>
              </thead>
              <tbody>
                {profileData.crimeIncidents.map((incident, idx) => (
                  <tr key={idx} className="border border-gray-300">
                    <td className="border border-gray-300 p-3 font-semibold">{incident.nature}</td>
                    <td className="border border-gray-300 p-3">{incident.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Hazard Matrix */}
      <Card className="mb-8 shadow-lg">
        <CardHeader>
          <CardTitle className="text-xl">G. Hazard Matrix</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse border border-gray-300">
              <thead>
                <tr className="bg-gray-100">
                  <th className="border border-gray-300 p-3 font-semibold">Hazard</th>
                  <th className="border border-gray-300 p-3 font-semibold">Location</th>
                  <th className="border border-gray-300 p-3 font-semibold">Tourist Attraction Location</th>
                  <th className="border border-gray-300 p-3 font-semibold">No. of Population Affected</th>
                </tr>
              </thead>
              <tbody>
                {profileData.hazards.map((hazard) => (
                  <tr key={hazard.id} className="border border-gray-300">
                    <td className="border border-gray-300 p-3 font-semibold">{hazard.hazard}</td>
                    <td className="border border-gray-300 p-3">{hazard.location}</td>
                    <td className="border border-gray-300 p-3">{hazard.touristAttractionLocation}</td>
                    <td className="border border-gray-300 p-3">{hazard.populationAffected}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Multiple-hazard Maps */}
      {profileData.hazardMapsUrls.length > 0 && (
        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl">H. Multiple-hazard Maps</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-6">
              {profileData.hazardMapsUrls.map((mapUrl, idx) => (
                <div key={idx} className="border rounded-lg p-4 bg-white">
                  <img src={mapUrl} alt={`Hazard Map ${idx + 1}`} className="w-full h-auto rounded" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
}

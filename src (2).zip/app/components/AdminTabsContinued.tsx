import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { Plus, X } from 'lucide-react';
import type { ProfileData, InstitutionalElement, EmergencyContact, TourismEducation, TourismProject, Hazard } from '../data/profileData';

interface AdminTabsProps {
  profileData: ProfileData;
  setProfileData: (data: ProfileData) => void;
}

export function InstitutionalTab({ profileData, setProfileData }: AdminTabsProps) {
  const addElement = () => {
    const newElement: InstitutionalElement = {
      id: Date.now().toString(),
      groups: '',
      roleInTourism: '',
      organizationName: '',
      addressContact: '',
    };
    setProfileData({
      ...profileData,
      institutionalElements: [...profileData.institutionalElements, newElement],
    });
  };

  const removeElement = (id: string) => {
    setProfileData({
      ...profileData,
      institutionalElements: profileData.institutionalElements.filter(e => e.id !== id),
    });
  };

  const updateElement = (id: string, field: keyof InstitutionalElement, value: string) => {
    setProfileData({
      ...profileData,
      institutionalElements: profileData.institutionalElements.map(e =>
        e.id === id ? { ...e, [field]: value } : e
      ),
    });
  };

  const updateLaborForce = (index: number, field: 'male' | 'female', value: string) => {
    const newLaborForce = [...profileData.laborForce];
    newLaborForce[index] = { ...newLaborForce[index], [field]: value };
    setProfileData({ ...profileData, laborForce: newLaborForce });
  };

  const updateRevenue = (index: number, field: 'year1' | 'year2' | 'year3', value: string) => {
    const newRevenue = [...profileData.revenueContributions];
    newRevenue[index] = { ...newRevenue[index], [field]: value };
    setProfileData({ ...profileData, revenueContributions: newRevenue });
  };

  return (
    <div className="space-y-6">
      {/* Institutional Elements */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Accommodation and Other Facilities (Groups)</CardTitle>
            <Button onClick={addElement} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Add Group
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {profileData.institutionalElements.map((element) => (
            <div key={element.id} className="border rounded-lg p-4 relative">
              <Button
                variant="destructive"
                size="sm"
                className="absolute top-2 right-2"
                onClick={() => removeElement(element.id)}
              >
                <X className="h-4 w-4" />
              </Button>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                <div className="space-y-2">
                  <Label>Groups</Label>
                  <Input
                    value={element.groups}
                    onChange={(e) => updateElement(element.id, 'groups', e.target.value)}
                    placeholder="e.g., Hotels Association"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Role in Tourism</Label>
                  <Input
                    value={element.roleInTourism}
                    onChange={(e) => updateElement(element.id, 'roleInTourism', e.target.value)}
                    placeholder="Role in tourism industry"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Name of Organization and Head</Label>
                  <Input
                    value={element.organizationName}
                    onChange={(e) => updateElement(element.id, 'organizationName', e.target.value)}
                    placeholder="Organization name and head person"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Address and Contact Details</Label>
                  <Input
                    value={element.addressContact}
                    onChange={(e) => updateElement(element.id, 'addressContact', e.target.value)}
                    placeholder="Complete address and contact"
                  />
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Labor Force */}
      <Card>
        <CardHeader>
          <CardTitle>Labor Force</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {profileData.laborForce.map((labor, idx) => (
              <div key={idx} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center border-b pb-3">
                <div>
                  <Label className="font-semibold">{labor.category}</Label>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm">Male</Label>
                  <Input
                    value={labor.male}
                    onChange={(e) => updateLaborForce(idx, 'male', e.target.value)}
                    placeholder="Number of male employees"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm">Female</Label>
                  <Input
                    value={labor.female}
                    onChange={(e) => updateLaborForce(idx, 'female', e.target.value)}
                    placeholder="Number of female employees"
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Revenue Contributions */}
      <Card>
        <CardHeader>
          <CardTitle>Total Revenue Contributions to LGU (Past 3 Years)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {profileData.revenueContributions.map((revenue, idx) => (
              <div key={idx} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center border-b pb-3">
                <div>
                  <Label className="font-semibold">{revenue.category}</Label>
                </div>
                <div className="space-y-2">
                  <Label className="text-sm">Year 1 (PhP)</Label>
                  <Input
                    value={revenue.year1}
                    onChange={(e) => updateRevenue(idx, 'year1', e.target.value)}
                    placeholder="Amount"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm">Year 2 (PhP)</Label>
                  <Input
                    value={revenue.year2}
                    onChange={(e) => updateRevenue(idx, 'year2', e.target.value)}
                    placeholder="Amount"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-sm">Year 3 (PhP)</Label>
                  <Input
                    value={revenue.year3}
                    onChange={(e) => updateRevenue(idx, 'year3', e.target.value)}
                    placeholder="Amount"
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export function EmergencyContactsTab({ profileData, setProfileData }: AdminTabsProps) {
  const addContact = () => {
    const newContact: EmergencyContact = {
      id: Date.now().toString(),
      office: '',
      contactPerson: '',
      address: '',
      phoneNumber: '',
    };
    setProfileData({
      ...profileData,
      emergencyContacts: [...profileData.emergencyContacts, newContact],
    });
  };

  const removeContact = (id: string) => {
    setProfileData({
      ...profileData,
      emergencyContacts: profileData.emergencyContacts.filter(c => c.id !== id),
    });
  };

  const updateContact = (id: string, field: keyof EmergencyContact, value: string) => {
    setProfileData({
      ...profileData,
      emergencyContacts: profileData.emergencyContacts.map(c =>
        c.id === id ? { ...c, [field]: value } : c
      ),
    });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Emergency Contacts</CardTitle>
          <Button onClick={addContact} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            Add Contact
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {profileData.emergencyContacts.map((contact) => (
          <div key={contact.id} className="border rounded-lg p-4 relative">
            <Button
              variant="destructive"
              size="sm"
              className="absolute top-2 right-2"
              onClick={() => removeContact(contact.id)}
            >
              <X className="h-4 w-4" />
            </Button>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              <div className="space-y-2">
                <Label>Office/Agency</Label>
                <Input
                  value={contact.office}
                  onChange={(e) => updateContact(contact.id, 'office', e.target.value)}
                  placeholder="e.g., Police Station, Fire Department"
                />
              </div>
              <div className="space-y-2">
                <Label>Contact Person</Label>
                <Input
                  value={contact.contactPerson}
                  onChange={(e) => updateContact(contact.id, 'contactPerson', e.target.value)}
                  placeholder="Name of contact person"
                />
              </div>
              <div className="space-y-2">
                <Label>Address</Label>
                <Input
                  value={contact.address}
                  onChange={(e) => updateContact(contact.id, 'address', e.target.value)}
                  placeholder="Complete address"
                />
              </div>
              <div className="space-y-2">
                <Label>Phone Number</Label>
                <Input
                  value={contact.phoneNumber}
                  onChange={(e) => updateContact(contact.id, 'phoneNumber', e.target.value)}
                  placeholder="Contact number"
                />
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

export function TourismEducationTab({ profileData, setProfileData }: AdminTabsProps) {
  const addEducation = () => {
    const newEducation: TourismEducation = {
      id: Date.now().toString(),
      title: '',
      dateVenue: '',
      participantsMale: '',
      participantsFemale: '',
      participantGroups: '',
      organizedBy: '',
    };
    setProfileData({
      ...profileData,
      tourismEducation: [...profileData.tourismEducation, newEducation],
    });
  };

  const removeEducation = (id: string) => {
    setProfileData({
      ...profileData,
      tourismEducation: profileData.tourismEducation.filter(e => e.id !== id),
    });
  };

  const updateEducation = (id: string, field: keyof TourismEducation, value: string) => {
    setProfileData({
      ...profileData,
      tourismEducation: profileData.tourismEducation.map(e =>
        e.id === id ? { ...e, [field]: value } : e
      ),
    });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Tourism Education</CardTitle>
          <Button onClick={addEducation} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            Add Training
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {profileData.tourismEducation.map((edu) => (
          <div key={edu.id} className="border rounded-lg p-4 relative">
            <Button
              variant="destructive"
              size="sm"
              className="absolute top-2 right-2"
              onClick={() => removeEducation(edu.id)}
            >
              <X className="h-4 w-4" />
            </Button>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              <div className="space-y-2 md:col-span-2">
                <Label>Title of Training/Study Tours</Label>
                <Input
                  value={edu.title}
                  onChange={(e) => updateEducation(edu.id, 'title', e.target.value)}
                  placeholder="Training title"
                />
              </div>
              <div className="space-y-2">
                <Label>Date, Venue</Label>
                <Input
                  value={edu.dateVenue}
                  onChange={(e) => updateEducation(edu.id, 'dateVenue', e.target.value)}
                  placeholder="Date and venue"
                />
              </div>
              <div className="space-y-2">
                <Label>Participant Groups</Label>
                <Input
                  value={edu.participantGroups}
                  onChange={(e) => updateEducation(edu.id, 'participantGroups', e.target.value)}
                  placeholder="e.g., Tour guides, hotel staff"
                />
              </div>
              <div className="space-y-2">
                <Label>Male Participants</Label>
                <Input
                  value={edu.participantsMale}
                  onChange={(e) => updateEducation(edu.id, 'participantsMale', e.target.value)}
                  placeholder="Number of male participants"
                />
              </div>
              <div className="space-y-2">
                <Label>Female Participants</Label>
                <Input
                  value={edu.participantsFemale}
                  onChange={(e) => updateEducation(edu.id, 'participantsFemale', e.target.value)}
                  placeholder="Number of female participants"
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Organized/Conducted by</Label>
                <Input
                  value={edu.organizedBy}
                  onChange={(e) => updateEducation(edu.id, 'organizedBy', e.target.value)}
                  placeholder="Organization or agency"
                />
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

export function TourismProjectsTab({ profileData, setProfileData }: AdminTabsProps) {
  const addProject = () => {
    const newProject: TourismProject = {
      id: Date.now().toString(),
      name: '',
      duration: '',
      implementingAgency: '',
      partners: '',
      amount: '',
      sourcesOfFunds: '',
    };
    setProfileData({
      ...profileData,
      tourismProjects: [...profileData.tourismProjects, newProject],
    });
  };

  const removeProject = (id: string) => {
    setProfileData({
      ...profileData,
      tourismProjects: profileData.tourismProjects.filter(p => p.id !== id),
    });
  };

  const updateProject = (id: string, field: keyof TourismProject, value: string) => {
    setProfileData({
      ...profileData,
      tourismProjects: profileData.tourismProjects.map(p =>
        p.id === id ? { ...p, [field]: value } : p
      ),
    });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Tourism Projects (Past 5 Years)</CardTitle>
          <Button onClick={addProject} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            Add Project
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {profileData.tourismProjects.map((project) => (
          <div key={project.id} className="border rounded-lg p-4 relative">
            <Button
              variant="destructive"
              size="sm"
              className="absolute top-2 right-2"
              onClick={() => removeProject(project.id)}
            >
              <X className="h-4 w-4" />
            </Button>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              <div className="space-y-2 md:col-span-2">
                <Label>Name of Project</Label>
                <Input
                  value={project.name}
                  onChange={(e) => updateProject(project.id, 'name', e.target.value)}
                  placeholder="Project name"
                />
              </div>
              <div className="space-y-2">
                <Label>Duration</Label>
                <Input
                  value={project.duration}
                  onChange={(e) => updateProject(project.id, 'duration', e.target.value)}
                  placeholder="e.g., 2020-2022"
                />
              </div>
              <div className="space-y-2">
                <Label>Implementing Agency</Label>
                <Input
                  value={project.implementingAgency}
                  onChange={(e) => updateProject(project.id, 'implementingAgency', e.target.value)}
                  placeholder="Agency name"
                />
              </div>
              <div className="space-y-2">
                <Label>Partners</Label>
                <Input
                  value={project.partners}
                  onChange={(e) => updateProject(project.id, 'partners', e.target.value)}
                  placeholder="Partner organizations"
                />
              </div>
              <div className="space-y-2">
                <Label>Amount</Label>
                <Input
                  value={project.amount}
                  onChange={(e) => updateProject(project.id, 'amount', e.target.value)}
                  placeholder="e.g., ₱5,000,000"
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Sources of Funds</Label>
                <Input
                  value={project.sourcesOfFunds}
                  onChange={(e) => updateProject(project.id, 'sourcesOfFunds', e.target.value)}
                  placeholder="Funding sources"
                />
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

export function SafetySecurityTab({ profileData, setProfileData }: AdminTabsProps) {
  const updateCrimeIncident = (index: number, description: string) => {
    const newIncidents = [...profileData.crimeIncidents];
    newIncidents[index] = { ...newIncidents[index], description };
    setProfileData({ ...profileData, crimeIncidents: newIncidents });
  };

  const updateHazard = (id: string, field: keyof Hazard, value: string) => {
    setProfileData({
      ...profileData,
      hazards: profileData.hazards.map(h =>
        h.id === id ? { ...h, [field]: value } : h
      ),
    });
  };

  return (
    <div className="space-y-6">
      {/* Crime Incidents */}
      <Card>
        <CardHeader>
          <CardTitle>Peace and Order - Incidence of Crime</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {profileData.crimeIncidents.map((incident, idx) => (
              <div key={idx} className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center border-b pb-3">
                <div>
                  <Label className="font-semibold">{incident.nature}</Label>
                </div>
                <div className="space-y-2">
                  <Textarea
                    value={incident.description}
                    onChange={(e) => updateCrimeIncident(idx, e.target.value)}
                    placeholder="Description or notes"
                    rows={2}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Hazard Matrix */}
      <Card>
        <CardHeader>
          <CardTitle>Hazard Matrix</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {profileData.hazards.map((hazard) => (
              <div key={hazard.id} className="border rounded-lg p-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="font-semibold">{hazard.hazard}</Label>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm">Location</Label>
                    <Input
                      value={hazard.location}
                      onChange={(e) => updateHazard(hazard.id, 'location', e.target.value)}
                      placeholder="Location affected"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm">Tourist Attraction Location</Label>
                    <Input
                      value={hazard.touristAttractionLocation}
                      onChange={(e) => updateHazard(hazard.id, 'touristAttractionLocation', e.target.value)}
                      placeholder="Nearby tourist attraction"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-sm">No. of Population Affected</Label>
                    <Input
                      value={hazard.populationAffected}
                      onChange={(e) => updateHazard(hazard.id, 'populationAffected', e.target.value)}
                      placeholder="Population count"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { Plus, X } from 'lucide-react';
import type { ProfileData, TourismAttraction, AccommodationFacility, AccommodationProfile, InstitutionalElement, EmergencyContact, TourismEducation, TourismProject, Hazard } from '../data/profileData';

interface AdminTabsProps {
  profileData: ProfileData;
  setProfileData: (data: ProfileData) => void;
}

export function TourismAttractionsTab({ profileData, setProfileData }: AdminTabsProps) {
  const addAttraction = () => {
    const newAttraction: TourismAttraction = {
      id: Date.now().toString(),
      category: '',
      attraction: '',
      location: '',
      activities: '',
    };
    setProfileData({
      ...profileData,
      tourismAttractions: [...profileData.tourismAttractions, newAttraction],
    });
  };

  const removeAttraction = (id: string) => {
    setProfileData({
      ...profileData,
      tourismAttractions: profileData.tourismAttractions.filter(a => a.id !== id),
    });
  };

  const updateAttraction = (id: string, field: keyof TourismAttraction, value: string) => {
    setProfileData({
      ...profileData,
      tourismAttractions: profileData.tourismAttractions.map(a =>
        a.id === id ? { ...a, [field]: value } : a
      ),
    });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Tourism Attractions and Activities</CardTitle>
          <Button onClick={addAttraction} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            Add Attraction
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {profileData.tourismAttractions.map((attraction) => (
          <div key={attraction.id} className="border rounded-lg p-4 relative">
            <Button
              variant="destructive"
              size="sm"
              className="absolute top-2 right-2"
              onClick={() => removeAttraction(attraction.id)}
            >
              <X className="h-4 w-4" />
            </Button>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
              <div className="space-y-2">
                <Label>Category</Label>
                <Input
                  value={attraction.category}
                  onChange={(e) => updateAttraction(attraction.id, 'category', e.target.value)}
                  placeholder="e.g., Beach, Church, etc."
                />
              </div>
              <div className="space-y-2">
                <Label>Attraction Name</Label>
                <Input
                  value={attraction.attraction}
                  onChange={(e) => updateAttraction(attraction.id, 'attraction', e.target.value)}
                  placeholder="Name of attraction"
                />
              </div>
              <div className="space-y-2">
                <Label>Location</Label>
                <Input
                  value={attraction.location}
                  onChange={(e) => updateAttraction(attraction.id, 'location', e.target.value)}
                  placeholder="Barangay or specific location"
                />
              </div>
              <div className="space-y-2">
                <Label>Activities</Label>
                <Input
                  value={attraction.activities}
                  onChange={(e) => updateAttraction(attraction.id, 'activities', e.target.value)}
                  placeholder="e.g., Swimming, diving, etc."
                />
              </div>
            </div>
          </div>
        ))}
        {profileData.tourismAttractions.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No tourism attractions added yet. Click "Add Attraction" to begin.
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function AccommodationTab({ profileData, setProfileData }: AdminTabsProps) {
  const addFacility = () => {
    const newFacility: AccommodationFacility = {
      id: Date.now().toString(),
      nature: '',
      establishment: '',
      location: '',
      contactDetails: '',
    };
    setProfileData({
      ...profileData,
      accommodationFacilities: [...profileData.accommodationFacilities, newFacility],
    });
  };

  const removeFacility = (id: string) => {
    setProfileData({
      ...profileData,
      accommodationFacilities: profileData.accommodationFacilities.filter(f => f.id !== id),
    });
  };

  const updateFacility = (id: string, field: keyof AccommodationFacility, value: string) => {
    setProfileData({
      ...profileData,
      accommodationFacilities: profileData.accommodationFacilities.map(f =>
        f.id === id ? { ...f, [field]: value } : f
      ),
    });
  };

  const addProfile = () => {
    const newProfile: AccommodationProfile = {
      id: Date.now().toString(),
      name: '',
      type: '',
      numberOfRooms: '',
      averageRate: '',
      occupancyRate: '',
    };
    setProfileData({
      ...profileData,
      accommodationProfiles: [...profileData.accommodationProfiles, newProfile],
    });
  };

  const removeProfile = (id: string) => {
    setProfileData({
      ...profileData,
      accommodationProfiles: profileData.accommodationProfiles.filter(p => p.id !== id),
    });
  };

  const updateProfile = (id: string, field: keyof AccommodationProfile, value: string) => {
    setProfileData({
      ...profileData,
      accommodationProfiles: profileData.accommodationProfiles.map(p =>
        p.id === id ? { ...p, [field]: value } : p
      ),
    });
  };

  return (
    <div className="space-y-6">
      {/* Accommodation Facilities */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Accommodation and Other Facilities</CardTitle>
            <Button onClick={addFacility} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Add Facility
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {profileData.accommodationFacilities.map((facility) => (
            <div key={facility.id} className="border rounded-lg p-4 relative">
              <Button
                variant="destructive"
                size="sm"
                className="absolute top-2 right-2"
                onClick={() => removeFacility(facility.id)}
              >
                <X className="h-4 w-4" />
              </Button>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                <div className="space-y-2">
                  <Label>Nature</Label>
                  <Input
                    value={facility.nature}
                    onChange={(e) => updateFacility(facility.id, 'nature', e.target.value)}
                    placeholder="e.g., Resort, Hotel, Restaurant"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Establishment/Facility</Label>
                  <Input
                    value={facility.establishment}
                    onChange={(e) => updateFacility(facility.id, 'establishment', e.target.value)}
                    placeholder="Name of establishment"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Location</Label>
                  <Input
                    value={facility.location}
                    onChange={(e) => updateFacility(facility.id, 'location', e.target.value)}
                    placeholder="Address or barangay"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Contact Details</Label>
                  <Input
                    value={facility.contactDetails}
                    onChange={(e) => updateFacility(facility.id, 'contactDetails', e.target.value)}
                    placeholder="Phone, email, etc."
                  />
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Accommodation Profiles */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Accommodation Profile</CardTitle>
            <Button onClick={addProfile} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Add Profile
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {profileData.accommodationProfiles.map((profile) => (
            <div key={profile.id} className="border rounded-lg p-4 relative">
              <Button
                variant="destructive"
                size="sm"
                className="absolute top-2 right-2"
                onClick={() => removeProfile(profile.id)}
              >
                <X className="h-4 w-4" />
              </Button>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
                <div className="space-y-2">
                  <Label>Name of Establishment</Label>
                  <Input
                    value={profile.name}
                    onChange={(e) => updateProfile(profile.id, 'name', e.target.value)}
                    placeholder="Establishment name"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Type</Label>
                  <Input
                    value={profile.type}
                    onChange={(e) => updateProfile(profile.id, 'type', e.target.value)}
                    placeholder="e.g., Hotel, Resort"
                  />
                </div>
                <div className="space-y-2">
                  <Label># of Rooms</Label>
                  <Input
                    value={profile.numberOfRooms}
                    onChange={(e) => updateProfile(profile.id, 'numberOfRooms', e.target.value)}
                    placeholder="Number of rooms"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Average Rate</Label>
                  <Input
                    value={profile.averageRate}
                    onChange={(e) => updateProfile(profile.id, 'averageRate', e.target.value)}
                    placeholder="e.g., ₱2,000/night"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Occupancy Rate</Label>
                  <Input
                    value={profile.occupancyRate}
                    onChange={(e) => updateProfile(profile.id, 'occupancyRate', e.target.value)}
                    placeholder="e.g., 75%"
                  />
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

export function TransportationTab({ profileData, setProfileData }: AdminTabsProps) {
  const updateTransportation = (id: string, field: 'schedules' | 'route' | 'averageFare', value: string) => {
    setProfileData({
      ...profileData,
      transportation: profileData.transportation.map(t =>
        t.id === id ? { ...t, [field]: value } : t
      ),
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Transportation</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {profileData.transportation.map((trans) => (
          <div key={trans.id} className="border rounded-lg p-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label>Type</Label>
                <Input value={trans.type} disabled className="bg-gray-100" />
              </div>
              <div className="space-y-2">
                <Label>Schedules</Label>
                <Input
                  value={trans.schedules}
                  onChange={(e) => updateTransportation(trans.id, 'schedules', e.target.value)}
                  placeholder="e.g., Daily 6AM-6PM"
                />
              </div>
              <div className="space-y-2">
                <Label>Route</Label>
                <Input
                  value={trans.route}
                  onChange={(e) => updateTransportation(trans.id, 'route', e.target.value)}
                  placeholder="e.g., Tagbilaran-Panglao"
                />
              </div>
              <div className="space-y-2">
                <Label>Average Fare</Label>
                <Input
                  value={trans.averageFare}
                  onChange={(e) => updateTransportation(trans.id, 'averageFare', e.target.value)}
                  placeholder="e.g., ₱25"
                />
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

export interface TourismAttraction {
  id: string;
  category: string;
  attraction: string;
  location: string;
  activities: string;
}

export interface AccommodationFacility {
  id: string;
  nature: string;
  establishment: string;
  location: string;
  contactDetails: string;
}

export interface AccommodationProfile {
  id: string;
  name: string;
  type: string;
  numberOfRooms: string;
  averageRate: string;
  occupancyRate: string;
}

export interface Transportation {
  id: string;
  type: string;
  schedules: string;
  route: string;
  averageFare: string;
}

export interface InstitutionalElement {
  id: string;
  groups: string;
  roleInTourism: string;
  organizationName: string;
  addressContact: string;
}

export interface LaborForce {
  category: string;
  male: string;
  female: string;
}

export interface RevenueContribution {
  category: string;
  year1: string;
  year2: string;
  year3: string;
}

export interface EmergencyContact {
  id: string;
  office: string;
  contactPerson: string;
  address: string;
  phoneNumber: string;
}

export interface TourismEducation {
  id: string;
  title: string;
  dateVenue: string;
  participantsMale: string;
  participantsFemale: string;
  participantGroups: string;
  organizedBy: string;
}

export interface TourismProject {
  id: string;
  name: string;
  duration: string;
  implementingAgency: string;
  partners: string;
  amount: string;
  sourcesOfFunds: string;
}

export interface CrimeIncident {
  nature: string;
  description: string;
}

export interface Hazard {
  id: string;
  hazard: string;
  location: string;
  touristAttractionLocation: string;
  populationAffected: string;
}

export interface ProfileData {
  basicInfo: {
    name: string;
    province: string;
    region: string;
    population: string;
    landArea: string;
    numberOfBarangays: string;
    ethnicGroups: string;
  };
  religions: string[];
  languages: string[];
  economicActivities: string[];
  officials: {
    mayor: string;
    viceMayor: string;
    sangguniang: string[];
    tourismOfficer: string;
    planningCoordinator: string;
  };
  tourismAttractions: TourismAttraction[];
  tourismMapUrl: string;
  accommodationFacilities: AccommodationFacility[];
  accommodationProfiles: AccommodationProfile[];
  transportation: Transportation[];
  institutionalElements: InstitutionalElement[];
  laborForce: LaborForce[];
  revenueContributions: RevenueContribution[];
  emergencyContacts: EmergencyContact[];
  tourismEducation: TourismEducation[];
  tourismProjects: TourismProject[];
  crimeIncidents: CrimeIncident[];
  hazards: Hazard[];
  hazardMapsUrls: string[];
}

export const initialProfileData: ProfileData = {
  basicInfo: {
    name: 'PANGLAO',
    province: 'BOHOL',
    region: 'VII',
    population: '',
    landArea: '47.79 km²',
    numberOfBarangays: '10',
    ethnicGroups: 'NONE',
  },
  religions: ['ROMAN CATHOLIC', 'PROTESTANTISM'],
  languages: ['VISAYAN', 'ENGLISH', 'FILIPINO'],
  economicActivities: ['TOURISM', 'FISHING', 'FARMING'],
  officials: {
    mayor: 'HON. EDGARDO F. ARCAY',
    viceMayor: 'HON. NOEL E. HORMACHUELOS',
    sangguniang: [
      'HON. DAISY DELAMIDE',
      'HON. DENNIS HORA',
      'HON. BENEDICT ALCALA',
      'HON. JOSE RAMON RODRIGUEZ',
      'HON. FIELE ANTHONY DUMALUAN',
      'HON. LEONILA MONTERO',
      'HON. EDUARD MEJOS',
      'HON. JOSE ARBITRARIO (EX-OFFICIO)',
      'HON. FELIX FUDOLIG',
      'HON. JONA LORETERO – SUMAYLO (EX-OFFICIO)',
    ],
    tourismOfficer: 'LEONIDES E. SENICA, MPA, CTP',
    planningCoordinator: 'JAIRUS D. FUDERANAN, EnP',
  },
  tourismAttractions: [],
  tourismMapUrl: '',
  accommodationFacilities: [],
  accommodationProfiles: [],
  transportation: [
    { id: '1', type: 'Jeepney', schedules: '', route: '', averageFare: '' },
    { id: '2', type: 'Bus', schedules: '', route: '', averageFare: '' },
    { id: '3', type: 'Van', schedules: '', route: '', averageFare: '' },
    { id: '4', type: 'Airplane', schedules: '', route: '', averageFare: '' },
    { id: '5', type: 'Boat', schedules: '', route: '', averageFare: '' },
    { id: '6', type: 'Tricycle', schedules: '', route: '', averageFare: '' },
    { id: '7', type: 'Habal-Habal', schedules: '', route: '', averageFare: '' },
    { id: '8', type: 'Others:', schedules: '', route: '', averageFare: '' },
  ],
  institutionalElements: [],
  laborForce: [
    { category: 'Accommodation', male: '', female: '' },
    { category: 'Travel Agency', male: '', female: '' },
    { category: 'Sea Transportation', male: '', female: '' },
    { category: 'Land Transportation', male: '', female: '' },
    { category: 'Air Transportation', male: '', female: '' },
    { category: 'Bars and Restaurants', male: '', female: '' },
    { category: 'Health and Wellness Centers', male: '', female: '' },
  ],
  revenueContributions: [
    { category: 'Accommodation', year1: '', year2: '', year3: '' },
    { category: 'Travel Agency', year1: '', year2: '', year3: '' },
    { category: 'Sea Transportation', year1: '', year2: '', year3: '' },
    { category: 'Land Transportation', year1: '', year2: '', year3: '' },
    { category: 'Air Transportation', year1: '', year2: '', year3: '' },
    { category: 'Bars and Restaurants', year1: '', year2: '', year3: '' },
    { category: 'Health and Wellness Centers', year1: '', year2: '', year3: '' },
    { category: 'MICE', year1: '', year2: '', year3: '' },
  ],
  emergencyContacts: [],
  tourismEducation: [],
  tourismProjects: [],
  crimeIncidents: [
    { nature: 'Kidnapping of Tourists', description: '' },
    { nature: 'Drowning of Tourists', description: '' },
    { nature: 'Petty theft involving local guides', description: '' },
    { nature: 'Road accidents involving tourists', description: '' },
    { nature: 'Prostitution/sexual harassment', description: '' },
    { nature: 'Use of prohibited drugs', description: '' },
    { nature: 'Pedophiles caught', description: '' },
    { nature: 'Masseurs got pregnant by tourist', description: '' },
    { nature: 'Trafficking of women and children', description: '' },
    { nature: 'Incidence of female tourists travelling alone', description: '' },
    { nature: 'Others:', description: '' },
  ],
  hazards: [
    { id: '1', hazard: 'Earthquake', location: '', touristAttractionLocation: '', populationAffected: '' },
    { id: '2', hazard: 'Landslide', location: '', touristAttractionLocation: '', populationAffected: '' },
    { id: '3', hazard: 'Storm Surge', location: '', touristAttractionLocation: '', populationAffected: '' },
    { id: '4', hazard: 'Tsunami', location: '', touristAttractionLocation: '', populationAffected: '' },
    { id: '5', hazard: 'Others:', location: '', touristAttractionLocation: '', populationAffected: '' },
  ],
  hazardMapsUrls: [],
};
